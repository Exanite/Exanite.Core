﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Exanite.Pool
{
	public enum PoolEmptyBehavior
	{
		ExpandPool = 0,
		ReuseObject = 1,
		DoNothing = 2,
	}
}