﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Exanite.Pool
{
	public interface IPoolable
	{
		void OnSpawn();

		void OnDespawn(); // Use this for reseting the GameObject's variables
	}
}