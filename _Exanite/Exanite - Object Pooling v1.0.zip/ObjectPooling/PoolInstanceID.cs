﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Exanite.Pool
{
	public class PoolInstanceID : MonoBehaviour 
	{
		public GameObject originalPrefab;
		public int instanceID;
	}
}